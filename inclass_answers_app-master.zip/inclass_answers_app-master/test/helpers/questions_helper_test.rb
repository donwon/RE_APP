require 'test_helper'

class QuestionsHelperTest < ActionView::TestCase
end
