require 'test_helper'

class AnswersHelperTest < ActionView::TestCase
end
