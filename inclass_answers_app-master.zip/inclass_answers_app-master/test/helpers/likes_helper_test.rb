require 'test_helper'

class LikesHelperTest < ActionView::TestCase
end
