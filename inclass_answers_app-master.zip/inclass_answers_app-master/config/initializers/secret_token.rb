# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
AwesomeAnswers::Application.config.secret_key_base = '13880624dbae93c4a3f9020d60a515d5a261377d1df9eb55edc43ad829700f8b41fcc7b6bddbf48f0843790b0e7b7798a0e3bd34e0eb13f9fa66a394e7267a31'
