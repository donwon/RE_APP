# Be sure to restart your server when you modify this file.

AwesomeAnswers::Application.config.session_store :cookie_store, key: '_awesome_answers_session'
